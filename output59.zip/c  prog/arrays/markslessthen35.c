#include <stdio.h>
int main() {
    int marks[10] = {50, 60, 56, 89, 23, 78, 65, 45, 89, 90};
    for(int i=0; i<10;i++){
        if(marks[i]<35){
        printf("%d", marks[i]);
        }
    }
    return 0;
}