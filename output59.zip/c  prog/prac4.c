#include <stdio.h>
int main() {                  //display array
}