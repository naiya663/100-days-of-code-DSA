#include <stdio.h>
#define MAX 100

int q[MAX];
int front = -1, rear = -1;

int isEmpty()
{
    return front == -1 || front > rear;
}

void enqueue(int x)
{
    if (rear == MAX - 1)
        return;
    if (front == -1)
        front = 0;
    q[++rear] = x;
}

int dequeue()
{
    if (isEmpty())
        return -1;
    return q[front++];
}

int size()
{
    if (isEmpty())
        return 0;
    return rear - front + 1;
}

void push(int x)
{
    int i, s = size();
    enqueue(x);
    for (i = 0; i < s; i++)
        enqueue(dequeue());
}

void pop()
{
    if (isEmpty())
        printf("Underflow\n");
    else
        printf("Popped: %d\n", dequeue());
}

void display()
{
    if (isEmpty())
        printf("Stack is empty\n");
    else
    {
        for (int i = front; i <= rear; i++)
            printf("%d ", q[i]);
        printf("\n");
    }
}

int main()
{
    int choice, value;

    while (1)
    {
        printf("\n1.Push\n2.Pop\n3.Display\n4.Exit\n");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter value: ");
            scanf("%d", &value);
            push(value);
            break;
        case 2:
            pop();
            break;
        case 3:
            display();
            break;
        case 4:
            return 0;
        default:
            printf("Invalid choice\n");
        }
    }
}