#include <stdio.h>
#include <string.h>
#define MAX 100

char queue[MAX];
int front = -1, rear = -1;

void insert(char ch)
{
    if (rear == MAX - 1)
        return;
    if (front == -1)
        front = 0;
    rear++;
    queue[rear] = ch;
}

char dequeue()
{
    if (front == -1 || front > rear)
        return '\0';
    return queue[front++];
}

int main()
{
    char str[100];
    int i, len, flag = 1;

    printf("Enter string: ");
    scanf("%s", str);

    len = strlen(str);

    for (i = 0; i < len; i++)
        insert(str[i]);

    for (i = 0; i < len / 2; i++)
    {
        if (dequeue() != str[len - 1 - i])
        {
            flag = 0;
            break;
        }
    }

    if (flag)
        printf("Palindrome\n");
    else
        printf("Not Palindrome\n");

    return 0;
}